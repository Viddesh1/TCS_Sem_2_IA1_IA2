
# coding: utf-8

# In[1]:


import os
os.getcwd()


# In[2]:


# Importing the necessary libraries.

import numpy as np # Importing numpy for numerical computation
import pandas as pd # Importing pandas for working with pre-processing and manipulation of dataframes
import matplotlib.pyplot as plt # Plotting library matplotlib
import seaborn as sns # Plotting library seaborn
from sklearn.linear_model import LogisticRegression # Importing logistic regression model
from sklearn.model_selection import train_test_split # Splitling in train and test set
from sklearn.linear_model import LogisticRegression # Importing logistic regression model
from sklearn.metrics import accuracy_score # Evaualating accuracy of logistic regression model


# In[3]:


# Reading the comma seperated (csv) file using pandas library to dataframe using read_csv() function
df = pd.read_csv(r"/home/user13/user13/IA_1/ML Project 1 Dataset.csv") 
df


# In[4]:


df.isna().sum() # Checking if there is a any null or missing columns in the dataset.


# In[5]:


# Removing all the unwanted white space from left and right of the columns.

df.rename(columns=lambda x: x.strip(), inplace=True)
df


# In[131]:


df.dtypes


# In[6]:


print("Unique values for 'New_CUST': ", set(df["NEW_CUST"]))
print("Unique values for 'SEX': ",set(df["SEX"]))


# In[7]:


df["NEW_CUST"] = df["NEW_CUST"].apply(lambda x : 1 if x == "YES" else 0)
df["SEX"] = df["SEX"].apply(lambda x : 1 if x == "F" else 0)


# In[8]:


df.dtypes


# In[9]:


# Co-relation plot of all the feature vectors that are highly co-related with the target variable.

plt.figure(figsize=(20, 15))
sns.heatmap(df.corr(),annot=True)
plt.show()


# In[10]:


# Plotting Box plot or 5 number summary to see the distribution and outliers.

red_circle = dict(markerfacecolor = 'red', marker='o')
plt.boxplot(df["AGE"], flierprops=red_circle)
plt.show()


# In[11]:


# Plotting Box plot or 5 number summary to see the distribution and outliers.

red_circle = dict(markerfacecolor = 'red', marker='o')
plt.boxplot(df["MON_IN_OCC"], flierprops=red_circle)
plt.show()


# In[12]:


# Plotting Box plot or 5 number summary to see the distribution and outliers.

red_circle = dict(markerfacecolor = 'red', marker='o')
plt.boxplot(df["LTV"], flierprops=red_circle)
plt.show()


# In[13]:


# Plotting Box plot or 5 number summary to see the distribution and outliers.

red_circle = dict(markerfacecolor = 'red', marker='o')
plt.boxplot(df["TENURE"], flierprops=red_circle)
plt.show()


# In[14]:


# Plotting Box plot or 5 number summary to see the distribution and outliers.

red_circle = dict(markerfacecolor = 'red', marker='o')
plt.boxplot(df["EMPLOYEE_TYPE"], flierprops=red_circle)
plt.show()


# In[15]:


# # Dealing with outliers using the capping method. Rather than deleting the outliers capping the outlieres are better choice.
# # Capping method is a method where I have added the outliers that was present to the left and right tail of the normal distrubution.

for i in df.columns:
    percentile25 = df[i].quantile(0.25)
    percentile75 = df[i].quantile(0.75)
    iqr = percentile75 - percentile25
    upper_limit = percentile75 + 1.5 * iqr
    lower_limit = percentile25 - 1.5 * iqr

    df[i] = np.where(df[i] > upper_limit, upper_limit, 
    np.where(
        df[i] < lower_limit, lower_limit, df[i]
    ))


# In[16]:


# Plotting Box plot or 5 number summary to see the distribution and outliers.

red_circle = dict(markerfacecolor = 'red', marker='o')
plt.boxplot(df["LTV"], flierprops=red_circle)
plt.show()


# In[17]:


# Plotting Box plot or 5 number summary to see the distribution and outliers.

red_circle = dict(markerfacecolor = 'red', marker='o')
plt.boxplot(df["MON_IN_OCC"], flierprops=red_circle)
plt.show()


# In[18]:


X = df.drop(columns= "STATUS")
X


# In[19]:


y = df[["STATUS"]]
y


# In[20]:


# Splitting the train and test data in X_train, X_test, y_train and y_test
# Where, 
# X_train and y_train will be for training.
# X_test and y_test will be for testing.

X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=104, test_size=0.25, shuffle=True)
print(f"X train: {X_train.shape}")
print(f"X test: {X_test.shape}")
print(f"y train: {y_train.shape}")
print(f"y test: {y_test.shape}")


# In[33]:


# Using sklearn's LogisticRegression model and training it with train datasets.

log_model = LogisticRegression() 
log_model.fit(X_train, y_train)


# In[32]:


## Hyper-Parameter tuning - Accuracy is decreasing. Given accuracy 54%
# log_model = LogisticRegression(penalty = 'l2', C=10, fit_intercept = True, intercept_scaling = 1, class_weight='balanced', random_state = 42, solver='saga') 
# log_model.fit(X_train, y_train)


# In[34]:


y_pred = log_model.predict(X_test) # Predicting on test dataset
y_pred


# In[35]:


# Evaluating the model accuracy of Logistic Regression model

# Accuracy = r2_score(y_test['No'], y_pred) * 100
Accuracy = accuracy_score(y_test, y_pred) * 100

print(f"Accuracy is: {Accuracy}")


# In[36]:


# Random forest
from sklearn.ensemble import RandomForestClassifier

clf = RandomForestClassifier(n_estimators=100)
clf.fit(X_train, y_train)


# In[38]:


## HyperParameter tuning - Random forest Classifier Accuracy is increasing:- 67%
from sklearn.ensemble import RandomForestClassifier

clf = RandomForestClassifier(n_estimators=100, max_depth= 30, min_samples_split= 20, min_samples_leaf=20)
clf.fit(X_train, y_train)


# In[39]:


y_pred = clf.predict(X_test) # Predicting on test dataset
Accuracy = accuracy_score(y_test, y_pred) * 100

print(f"Accuracy is: {Accuracy}")


# ### RandomForestClassifier :- 67%
