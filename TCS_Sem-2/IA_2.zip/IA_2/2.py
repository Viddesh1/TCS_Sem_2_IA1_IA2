
# coding: utf-8

# In[41]:


import os
os.getcwd()


# In[42]:


# Importing all the necessary libraries.

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn import svm
from sklearn.metrics import accuracy_score
import tensorflow as tf
import seaborn as sns
from tensorflow.keras import layers, models


# ### 1. Collect images of handwritten letters of one of the Indian languages 

# In[43]:


df = pd.read_csv(r'/home/user13/user13/IA_2/Dig-MNIST.csv')
df


# In[44]:


df.isnull().sum()


# In[45]:


df.info()


# In[46]:


df.describe()


# ### 2. Split the data into train and test tests (80% train and 20% test)

# In[47]:


X = df.loc[:, df.columns != "label"]
X


# In[48]:


y = df["label"]
y


# In[49]:


## Standardizing the data
standardized_data = StandardScaler().fit_transform(X)
print(standardized_data.shape)


# In[50]:


X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.80, test_size=0.20, random_state=42)


# In[51]:


X_train.shape


# In[52]:


X_test.shape


# In[53]:


y_train.shape


# In[54]:


y_test.shape


# ### 3. Use dimension reduction techniques, PCA and t-SNE to reduce the dimensions of the data

# In[55]:


# Applying PCA

pca = PCA(n_components=2) # project from 784 to 2 dimensions
principalComponents = pca.fit_transform(X)
principal_df = pd.DataFrame(data = principalComponents
             , columns = ['principal component 1', 'principal component 2'])
principal_df.shape


# In[56]:


# Explaining the Variance ratio
print('Explained variation per principal component: {}'.format(pca.explained_variance_ratio_))


# In[57]:


# Plot the first two principal components of each point to learn about the data:

plt.scatter(principalComponents[:, 0], principalComponents[:, 1], s= 5, c=y, cmap='Spectral')
plt.gca().set_aspect('equal', 'datalim')
plt.colorbar(boundaries=np.arange(11)-0.5).set_ticks(np.arange(10))
plt.title('Visualizing Kannada MNIST through PCA', fontsize=24)
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')


# In[58]:


pca = PCA(n_components=0.95)
X_reduced = pca.fit_transform(X)


# In[59]:


pca = PCA().fit(X)
plt.plot(np.cumsum(pca.explained_variance_ratio_))
plt.xlabel('number of components')
plt.ylabel('cumulative explained variance')


# In[60]:


# Applyting t-SNE on the data
get_ipython().magic('time')
tsne = TSNE(random_state = 42, n_components=2,verbose=0, perplexity=40, n_iter=300).fit_transform(X)


# In[61]:


plt.scatter(tsne[:, 0], tsne[:, 1], s= 5, c=y, cmap='Spectral')
plt.gca().set_aspect('equal', 'datalim')
plt.colorbar(boundaries=np.arange(11)-0.5).set_ticks(np.arange(10))
plt.title('Visualizing Kannada MNIST through t-SNE', fontsize=24)


# ### 4. Train and Validate classification model using neural networks and support vector machines on the training data

# In[62]:


# 4.1 --> Support Vector Machines --> Accuracy:- 92%

clf = svm.SVC()
clf.fit(X_train, y_train)


# In[ ]:


## 4.1 Hyper Parameter tuning --> Support Vector Machines --> Accuracy is decreased

# clf = svm.SVC(C=1.0, kernel="poly", degree=5, gamma="auto", random_state=102)
# clf.fit(X_train, y_train)


# In[63]:


y_pred = clf.predict(X_test)


# In[64]:


accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy(%) of the SVM is: ", accuracy * 100)


# In[65]:


# 4.2 --> classification model using CNN --> Accuracy 89%

# Normalizing the data
X_train = X_train / 255.0

# One-Hot Encoding
y_train = tf.keras.utils.to_categorical(y_train, num_classes=10, dtype="uint8")
# 0 --> [1, 0, 0, 0, 0, 0, 0, 0, 0, 0]


# In[66]:


# Whatever the size of the matrix is we reshape it to 28 X 28 matrix
X_train = X_train.values.reshape(-1, 28, 28, 1)
X_test = X_test.values.reshape(-1, 28, 28, 1)


# In[67]:


X_train.shape


# In[68]:


X_test.shape


# In[69]:


model = models.Sequential()
model.add(layers.Conv2D(32, (5, 5), activation = "relu", input_shape = (28, 28, 1)))
model.add(layers.Conv2D(32, (5, 5), activation = "relu"))
model.add(layers.MaxPooling2D((2, 2)))
model.add(layers.Dropout(0.25))

model.add(layers.Conv2D(64, (5, 5), activation = "relu"))
model.add(layers.Conv2D(64, (5, 5), activation = "relu"))
model.add(layers.MaxPooling2D((2, 2)))
model.add(layers.Dropout(0.25))

model.add(layers.Flatten())
model.add(layers.Dense(256, activation = "relu"))
model.add(layers.Dropout(0.25))
model.add(layers.Dense(10, activation = "softmax"))


# In[ ]:


## Hyper-Parameter tuning CNN Model --> Accuracy is decreased

# model = models.Sequential()
# model.add(layers.Conv2D(32, (5, 5), activation = layers.LeakyReLU(), input_shape = (28, 28, 1)))
# model.add(layers.Conv2D(32, (5, 5), activation = layers.LeakyReLU()))
# model.add(layers.MaxPooling2D((2, 2)))
# model.add(layers.Dropout(0.25))

# model.add(layers.Conv2D(64, (5, 5), activation = layers.LeakyReLU()))
# model.add(layers.Conv2D(64, (5, 5), activation = layers.LeakyReLU()))
# model.add(layers.MaxPooling2D((2, 2)))
# model.add(layers.Dropout(0.25))

# model.add(layers.Flatten())
# model.add(layers.Dense(256, activation = layers.LeakyReLU()))
# model.add(layers.Dropout(0.25))
# model.add(layers.Dense(10, activation = tf.nn.tanh))


# In[70]:


model.compile(optimizer = "adam", loss = "categorical_crossentropy", metrics = ["accuracy"])


# In[71]:


X_train.shape


# In[72]:


y_train.shape


# In[73]:


model.fit(X_train, y_train, batch_size=1000, epochs=10, verbose=2)


# In[74]:


# Predicting the model on the test data

y_pred_NN = model.predict(X_test)


# In[77]:


# # Getting the first predictions
y_pred_NN[0]


# In[79]:


max_index = 0
for i in range(0, len(y_pred_NN[0])):
    if y_pred_NN[0][i] > y_pred_NN[0][max_index]:
        max_index = 1

print("Predicted Value : ", max_index)

