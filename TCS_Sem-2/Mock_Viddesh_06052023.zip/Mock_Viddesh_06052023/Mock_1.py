
# coding: utf-8

# In[10]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix


# In[11]:


import os
os.getcwd()


# In[12]:


df = pd.read_csv(r"/home/user13/user13/Mock_Viddesh_06052023/product_demand.csv")

df.head()


# In[13]:


df.shape


# In[14]:


df.isnull().sum()


# In[15]:


df.isna().sum() # There is only one missing value in the Total Price column


# In[16]:


missing_values =  df.isna().sum()

for column in df.columns:
    if missing_values[column] <= 5:
        df = df.dropna(subset=[column])
    else:
        median_value = df[column].median()
        df[column] = df[column].fillna(median_value)


# In[17]:


df.isna().sum()


# In[18]:


df.columns


# In[19]:


# Scatter plot

plt.xlabel("Total Price")
plt.ylabel("Units Sold")
plt.scatter(df["Total Price"], df["Units Sold"])
plt.show()


# In[20]:


# corelation between different features in the datasets

df.info()


# In[21]:


df.describe()


# In[22]:


df["Base Price"].corr(df["Units Sold"]) # Negative corelation


# In[23]:


df["Total Price"].corr(df["Units Sold"]) # Negative corelation


# In[24]:


df["Total Price"].corr(df["Base Price"]) # Positive corelation


# In[25]:


sns.heatmap(df.corr(), annot=True)
plt.show()


# In[26]:


df.columns


# In[27]:


# Training DecisionTreeClassifier Model:-
X = df[["Total Price", "Base Price"]]
X.head()


# In[28]:


y = df["Units Sold"]
y.head()


# In[29]:


X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=104, test_size=0.25, shuffle=True)


# In[30]:


X_train.shape


# In[31]:


X_test.shape


# In[32]:


y_train.shape


# In[33]:


y_test.shape


# In[34]:


clf = DecisionTreeClassifier()
clf.fit(X_train, y_train)


# In[35]:


y_pred = clf.predict(X_test)
y_pred


# In[36]:


y_pred.ndim


# In[37]:


y_test.ndim


# In[38]:


accuracy_score(y_test, y_pred) 


# In[39]:


precision_score(y_test, y_pred, average="macro")


# In[40]:


recall_score(y_test, y_pred, average="macro")


# In[41]:


f1_score(y_test, y_pred, average="macro")


# In[42]:


conf_matrix = confusion_matrix(y_test, y_pred)
conf_matrix


# In[45]:


clf.predict([[133.00, 140.00]])


# ### For Total Price:- 133.00 and Base Price:- 140.00, Unit Sold is 27 
